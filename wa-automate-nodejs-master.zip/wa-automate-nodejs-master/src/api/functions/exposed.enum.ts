export enum ExposedFn {
  OnMessage = 'onMessage',
  OnAnyMessage = 'onAnyMessage',
  onAck = 'onAck',
  onParticipantsChanged = 'onParticipantsChanged',
  onStateChanged = 'onStateChanged',
}
