export interface Id {
  server: string;
  user: string;
  _serialized: string;
}
